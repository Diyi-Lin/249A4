
public interface implementation {
    
	 long getSerialNum();
    
     String getBrand();
    
	 int getYear();
    
     double getPrice();
   
     void setSerialNum(long other);
    
	 void setBrand(String other);
    
     void setYear(int other);

     void setPrice(double other);

     String toString();
  
     boolean equals(Object other);

}
